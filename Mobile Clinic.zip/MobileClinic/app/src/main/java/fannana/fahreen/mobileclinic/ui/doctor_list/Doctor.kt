package fannana.fahreen.mobileclinic.ui.doctor_list

data class Doctor (
    var name : String,
    var docDep : String,
    var visit: Double,

    var image: Int

)