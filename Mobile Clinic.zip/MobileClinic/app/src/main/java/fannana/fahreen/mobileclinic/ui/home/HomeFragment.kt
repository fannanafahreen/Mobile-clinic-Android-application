package fannana.fahreen.mobileclinic.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import fannana.fahreen.mobileclinic.R
import fannana.fahreen.mobileclinic.databinding.FragmentHomeBinding
import fannana.fahreen.mobileclinic.repo.PrefUtils
import fannana.fahreen.mobileclinic.ui.department.Department
import fannana.fahreen.mobileclinic.ui.department.DepartmentListAdapter
import fannana.fahreen.mobileclinic.ui.nav.NavDialogFragment

class HomeFragment : Fragment(), DepartmentListAdapter.DepartmentListener {

    private var _binding: FragmentHomeBinding? = null

    private val binding get() = _binding!!

    private var departmentList: MutableList<Department> = mutableListOf()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root


        binding.apply {

            btnTest.setOnClickListener {
                findNavController().navigate(R.id.nav_gallery)
            }
            drawer.setOnClickListener {
                val dialog = NavDialogFragment()
                dialog.show(parentFragmentManager, "")
            }
        }

        dummyData()
        setRecyclerView(departmentList)

        return root
    }

    private fun dummyData() {
        departmentList.add(Department("Cardiology", "D001",  R.mipmap.ic_heart))
        departmentList.add(Department("Nephrology","D002",     R.mipmap.ic_nephrology))
        departmentList.add(Department("Gynecology","D003",     R.mipmap.ic_gyne))
        departmentList.add(Department("Orthopedic", "D004",    R.mipmap.ic_joint))
        departmentList.add(Department("Rheumatology","D005",   R.mipmap.ic_medicine))

    }

    //calling Department Adapter
    private fun setRecyclerView(departmentList: MutableList<Department>) {
        val activity = activity
        if(activity != null){
        val adapter = DepartmentListAdapter(departmentList,requireActivity(), this)
        binding.rvDepartments.layoutManager = LinearLayoutManager(requireActivity() ,LinearLayoutManager.HORIZONTAL ,false)
        binding.rvDepartments.isNestedScrollingEnabled = false
        binding.rvDepartments.adapter = adapter }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    override fun onDepartmentClick(dep: Department, pos: Int) {
        context?.let { PrefUtils.init(it).saveStringData(PrefUtils.PREF_DEP_CODE, dep.depCode) }
        findNavController().navigate(R.id.nav_doctor_list)
    }

}