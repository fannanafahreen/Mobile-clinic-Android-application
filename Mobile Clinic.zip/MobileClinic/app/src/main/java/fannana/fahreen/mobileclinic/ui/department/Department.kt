package fannana.fahreen.mobileclinic.ui.department

data class Department(

    val depName: String,
    val depCode: String,
    val imageResId: Int
    )
